#!/bin/bash

# RAT v4 Linux System Requirements Installation Script
# This script installs all system dependencies needed for the RAT v4 project
# Note: Python packages from requirements.txt should be installed manually

set -e  # Exit on any error

echo "=========================================="
echo "RAT v4 Linux System Requirements Installer"
echo "=========================================="
echo ""

# Note: This script can be run as root or regular user
# If run as regular user, sudo will be used when needed

# Detect Linux distribution
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
    VER=$VERSION_ID
else
    echo "Cannot detect Linux distribution. Exiting."
    exit 1
fi

echo "Detected OS: $OS $VER"
echo ""

# Function to install packages based on distribution
install_packages() {
    local packages="$1"
    local distro="$2"
    
    # Check if running as root
    local sudo_cmd=""
    if [[ $EUID -ne 0 ]]; then
        sudo_cmd="sudo"
    fi
    
    case $distro in
        *"Ubuntu"*|*"Debian"*|*"Linux Mint"*|*"Pop!_OS"*|*"Elementary"*)
            echo "Installing packages for Debian/Ubuntu-based system..."
            $sudo_cmd apt-get update
            $sudo_cmd apt-get install -y $packages
            ;;
        *"CentOS"*|*"Red Hat"*|*"Fedora"*|*"Rocky"*|*"AlmaLinux"*)
            echo "Installing packages for Red Hat-based system..."
            if command -v dnf &> /dev/null; then
                $sudo_cmd dnf install -y $packages
            elif command -v yum &> /dev/null; then
                $sudo_cmd yum install -y $packages
            else
                echo "Neither dnf nor yum found. Please install packages manually."
                return 1
            fi
            ;;
        *"Arch"*|*"Manjaro"*)
            echo "Installing packages for Arch-based system..."
            $sudo_cmd pacman -S --noconfirm $packages
            ;;
        *"openSUSE"*|*"SUSE"*)
            echo "Installing packages for openSUSE system..."
            $sudo_cmd zypper install -y $packages
            ;;
        *)
            echo "Unsupported distribution: $OS"
            echo "Please install the following packages manually:"
            echo "$packages"
            return 1
            ;;
    esac
}

# Core system packages
echo "Installing core system packages..."
CORE_PACKAGES="python3 python3-pip python3-dev python3-venv build-essential"

# Audio packages (for microphone functionality)
echo "Installing audio packages..."
AUDIO_PACKAGES="portaudio19-dev libasound2-dev libpulse-dev"

# Video packages (for webcam functionality)
echo "Installing video packages..."
VIDEO_PACKAGES="libopencv-dev python3-opencv libv4l-dev v4l-utils"

# GUI packages (for screenshots and GUI automation)
echo "Installing GUI packages..."
GUI_PACKAGES="python3-tk python3-gi python3-gi-cairo gir1.2-gtk-3.0 libgtk-3-dev"

# Additional development packages
echo "Installing additional development packages..."
DEV_PACKAGES="libssl-dev libffi-dev libcurl4-openssl-dev libxml2-dev libxslt1-dev"

# Image processing packages
echo "Installing image processing packages..."
IMAGE_PACKAGES="libjpeg-dev libpng-dev libtiff-dev libfreetype6-dev"

# Network and system packages
echo "Installing network and system packages..."
NETWORK_PACKAGES="curl wget git"

# Combine all packages
ALL_PACKAGES="$CORE_PACKAGES $AUDIO_PACKAGES $VIDEO_PACKAGES $GUI_PACKAGES $DEV_PACKAGES $IMAGE_PACKAGES $NETWORK_PACKAGES"

# Install packages
install_packages "$ALL_PACKAGES" "$OS"

echo ""
echo "=========================================="
echo "System packages installation completed!"
echo "=========================================="
echo ""

# Add user to required groups (only if not already in them)
echo "Checking and adding user to required groups..."

# Function to add user to groups if not already in them
add_to_groups() {
    local target_user="$1"
    local groups_to_add=""
    
    # Check if user is in audio group
    if ! groups "$target_user" | grep -q "audio"; then
        groups_to_add="$groups_to_add audio"
    fi
    
    # Check if user is in video group
    if ! groups "$target_user" | grep -q "video"; then
        groups_to_add="$groups_to_add video"
    fi
    
    # Add to groups if needed
    if [[ -n "$groups_to_add" ]]; then
        echo "Adding $target_user to groups:$groups_to_add"
        if [[ $EUID -eq 0 ]]; then
            usermod -a -G "$groups_to_add" "$target_user"
        else
            sudo usermod -a -G "$groups_to_add" "$target_user"
        fi
        echo "✓ Added $target_user to groups:$groups_to_add"
    else
        echo "✓ $target_user is already in both audio and video groups"
    fi
}

# Determine target user
if [[ $EUID -eq 0 ]]; then
    # Running as root
    if [[ -n "$SUDO_USER" ]]; then
        # Script was run with sudo
        add_to_groups "$SUDO_USER"
    else
        # Script was run directly as root
        echo "Warning: Running as root without SUDO_USER. Please specify username:"
        echo "usermod -a -G audio,video <username>"
    fi
else
    # Running as regular user
    add_to_groups "$USER"
fi
echo ""

# Check Python version
echo "Checking Python installation..."
python3 --version
pip3 --version

echo ""
echo "=========================================="
echo "Next Steps:"
echo "=========================================="
echo "1. Create a virtual environment (recommended):"
echo "   python3 -m venv venv"
echo "   source venv/bin/activate"
echo ""
echo "2. Install Python packages from requirements.txt:"
echo "   pip install -r requirements.txt"
echo ""
echo "3. For additional GUI support, you may need to install:"
echo "   - X11 development libraries (if not already installed)"
echo "   - Wayland support (if using Wayland instead of X11)"
echo ""
echo "4. Group membership has been automatically configured for audio and video access."
echo "   You may need to log out and back in for group changes to take effect."
echo "   Alternatively, you can run: newgrp audio && newgrp video"
echo ""

# Check if user is in required groups
echo "Checking user groups..."
if groups | grep -q audio; then
    echo "✓ User is in audio group"
else
    echo "⚠ User is NOT in audio group - you may need to log out and back in"
fi

if groups | grep -q video; then
    echo "✓ User is in video group"
else
    echo "⚠ User is NOT in video group - you may need to log out and back in"
fi

echo ""
echo "Installation completed successfully!"
echo "Please follow the next steps above to complete the setup."
