import os
import sys
import subprocess
import platform

PACKAGES = [
    ("flask", "flask"),
    ("requests", "requests"),
    ("psutil", "psutil"),
    ("waitress", "waitress"),
    ("pyaudio", "pyaudio"),
    ("pydub", "pydub"),
    ("pycurl", "pycurl"),
    ("Crypto", "pycryptodome"),
    ("pyperclip", "pyperclip"),
    ("PIL", "pillow"),
    ("pyautogui", "pyautogui"),
    ("cv2", "opencv-python"),
    ("PyInstaller", "pyinstaller"),
    ("keyboard", "keyboard"),
]

def in_venv():
    # Checks for virtual environment using several common strategies
    if hasattr(sys, 'real_prefix'):
        return True
    elif sys.base_prefix != sys.prefix:
        return True
    elif "VIRTUAL_ENV" in os.environ:
        return True
    return False

def print_venv_status():
    if in_venv():
        print("[+] Running inside a virtual environment.")
    else:
        print("[-] WARNING: Not running inside a virtual environment!")

def is_package_installed(import_name):
    try:
        __import__(import_name)
        return True
    except ImportError:
        return False

def is_headless():
    """Check if running in a headless environment (no display)"""
    return 'DISPLAY' not in os.environ

def ensure_packages():
    python_exe = sys.executable or "python"
    
    # Skip GUI packages if running headless
    packages_to_check = PACKAGES
    if is_headless():
        print("[+] Running in headless environment - skipping GUI packages")
        # Skip GUI-dependent packages
        gui_packages = ["pyaudio", "pydub", "pyperclip", "pillow", "pyautogui", "opencv-python", "keyboard"]
        packages_to_check = [(imp, pip) for imp, pip in PACKAGES if pip not in gui_packages]
    
    missing = []
    for import_name, pip_name in packages_to_check:
        if not is_package_installed(import_name):
            missing.append(pip_name)
    if missing:
        print(f"[+] Installing missing packages: {', '.join(missing)}")
        try:
            subprocess.run([python_exe, "-m", "pip", "install", "-U"] + missing, check=True)
        except Exception as e:
            print(f"[!] Failed to install packages: {e}")
    else:
        print("[+] All required packages are already installed.")

    # Install platform-specific dependencies
    system_name = platform.system().lower()
    if system_name.startswith("win"):
        # Windows-specific packages
        if not is_package_installed("win32com"):
            print("[+] Installing pywin32 for Windows...")
            try:
                subprocess.run([python_exe, "-m", "pip", "install", "-U", "pywin32"], check=True)
            except Exception as e:
                print(f"[!] Failed to install pywin32: {e}")
    elif system_name == "linux":
        # Linux-specific packages and system dependencies
        # Check for pyaudio system dependencies
        print("[*] Make sure 'portaudio19-dev' and 'python3-pyaudio' are installed system-wide!")
        # Check install with apt only if not present, but we can't check system-level deps from python
        if not is_package_installed("pyaudio"):
            print("[+] Attempting to install portaudio19-dev, python3-pyaudio (system packages)")
            try:
                subprocess.run(["sudo", "apt-get", "update"], check=False)
                subprocess.run(["sudo", "apt-get", "install", "-y", "portaudio19-dev", "python3-pyaudio"], check=False)
            except Exception as e:
                print(f"[!] Could not install system-level pyaudio dependencies: {e}")

if __name__ == "__main__":
    print_venv_status()
    ensure_packages()
    os.system("waitress-serve --host 0.0.0.0 --port 5000 run:app")
