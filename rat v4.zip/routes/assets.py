from flask import Blueprint, send_from_directory
import os

assets_bp = Blueprint('assets', __name__)

@assets_bp.route('/css/<path:filename>')
def css(filename):
    return send_from_directory('template/css', filename)

@assets_bp.route('/assets/<path:filename>')
def assets(filename):
    return send_from_directory('template/assets', filename)

# Serve downloadable files saved on the server
@assets_bp.route('/downloads/<path:filename>')
def downloads(filename):
    downloads_dir = os.path.join('template', 'downloads')
    # Ensure directory exists
    os.makedirs(downloads_dir, exist_ok=True)
    # Send as attachment to trigger browser download
    return send_from_directory(downloads_dir, filename, as_attachment=True)
