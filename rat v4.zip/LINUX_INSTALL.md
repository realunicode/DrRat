# RAT v4 Linux Installation Guide

## System Requirements Installation

Use the `for_linux.sh` script to install all necessary system dependencies for the RAT v4 project on Linux.

### Quick Start

1. **Make the script executable:**
   ```bash
   chmod +x for_linux.sh
   ```

2. **Run the installation script:**
   ```bash
   ./for_linux.sh
   ```

3. **Install Python packages manually:**
   ```bash
   # Create virtual environment (recommended)
   python3 -m venv venv
   source venv/bin/activate
   
   # Install Python dependencies
   pip install -r requirements.txt
   ```

### What the Script Installs

The `for_linux.sh` script installs the following system packages:

#### Core Packages
- Python 3 and development tools
- pip3 and build tools
- Essential development libraries

#### Audio Support (for microphone functionality)
- PortAudio development libraries
- ALSA and PulseAudio development libraries

#### Video Support (for webcam functionality)
- OpenCV development libraries
- V4L2 (Video4Linux) support
- Video utilities

#### GUI Support (for screenshots and automation)
- Tkinter and GTK development libraries
- GUI toolkit dependencies

#### Additional Development Libraries
- SSL/TLS libraries
- Cryptographic libraries
- XML/XSLT libraries
- Image processing libraries (JPEG, PNG, TIFF, FreeType)

#### Network Tools
- curl, wget, git

### Supported Linux Distributions

The script automatically detects and supports:
- **Debian/Ubuntu-based:** Ubuntu, Debian, Linux Mint, Pop!_OS, Elementary OS
- **Red Hat-based:** CentOS, Red Hat Enterprise Linux, Fedora, Rocky Linux, AlmaLinux
- **Arch-based:** Arch Linux, Manjaro
- **openSUSE:** openSUSE Leap, openSUSE Tumbleweed

### Post-Installation Steps

After running the script, you may need to:

1. **Add user to audio group** (for microphone access):
   ```bash
   sudo usermod -a -G audio $USER
   ```

2. **Add user to video group** (for webcam access):
   ```bash
   sudo usermod -a -G video $USER
   ```

3. **Log out and back in** for group changes to take effect.

### Troubleshooting

- **Audio issues:** Ensure your user is in the `audio` group
- **Webcam issues:** Ensure your user is in the `video` group and has camera permissions
- **GUI issues:** Make sure you're running in a desktop environment with X11 or Wayland
- **Permission errors:** The script will prompt for sudo when needed

### Manual Installation

If the script doesn't work for your distribution, install these packages manually:

**For Debian/Ubuntu:**
```bash
sudo apt-get update
sudo apt-get install python3 python3-pip python3-dev python3-venv build-essential portaudio19-dev libasound2-dev libpulse-dev libopencv-dev python3-opencv libv4l-dev v4l-utils python3-tk python3-gi python3-gi-cairo gir1.2-gtk-3.0 libgtk-3-dev libssl-dev libffi-dev libcurl4-openssl-dev libxml2-dev libxslt1-dev libjpeg-dev libpng-dev libtiff-dev libfreetype6-dev curl wget git
```

**For Red Hat/CentOS/Fedora:**
```bash
sudo dnf install python3 python3-pip python3-devel portaudio-devel alsa-lib-devel pulseaudio-libs-devel opencv-devel v4l-utils tkinter gtk3-devel openssl-devel libffi-devel libcurl-devel libxml2-devel libxslt-devel libjpeg-turbo-devel libpng-devel libtiff-devel freetype-devel curl wget git
```

**For Arch Linux:**
```bash
sudo pacman -S python python-pip portaudio alsa-lib pulseaudio opencv v4l-utils tk gtk3 openssl libffi curl libxml2 libxslt libjpeg-turbo libpng libtiff freetype2 curl wget git
```
