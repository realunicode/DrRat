import platform
import psutil
import socket
import uuid
import datetime
import os

def get_system_info():
    info = {}

    # OS info
    info["os"] = platform.system()
    info["os_version"] = platform.version()
    info["release"] = platform.release()
    info["architecture"] = platform.architecture()[0]
    info["machine"] = platform.machine()
    info["processor"] = platform.processor()

    # CPU info
    info["cpu_cores"] = psutil.cpu_count(logical=False)
    info["logical_cpus"] = psutil.cpu_count(logical=True)
    info["cpu_frequency_mhz"] = round(psutil.cpu_freq().current, 1)

    # RAM info
    svmem = psutil.virtual_memory()
    info["total_ram_gb"] = round(svmem.total / (1024 ** 3), 2)
    info["available_ram_gb"] = round(svmem.available / (1024 ** 3), 2)
    info["used_ram_gb"] = round(svmem.used / (1024 ** 3), 2)
    info["ram_usage_percent"] = svmem.percent

    # Disk info
    disk = psutil.disk_usage('/')
    info["total_disk_gb"] = round(disk.total / (1024 ** 3), 2)
    info["used_disk_gb"] = round(disk.used / (1024 ** 3), 2)
    info["free_disk_gb"] = round(disk.free / (1024 ** 3), 2)
    info["disk_usage_percent"] = disk.percent

    # Network info
    info["hostname"] = socket.gethostname()
    try:
        info["ip_address"] = socket.gethostbyname(socket.gethostname())
    except:
        info["ip_address"] = "Unavailable"
    info["mac_address"] = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff)
                                    for ele in range(0, 8*6, 8)][::-1])

    # User info
    try:
        info["user"] = os.getlogin()
    except:
        info["user"] = "Unavailable"

    # Boot time
    boot_time = datetime.datetime.fromtimestamp(psutil.boot_time())
    info["boot_time"] = boot_time.strftime("%Y-%m-%d %H:%M:%S")

    return info