import subprocess
import platform
from features.hide import _get_subprocess_kwargs

def _run_cmd(command: str) -> int:
    if platform.system().lower() == 'windows':
        kwargs = _get_subprocess_kwargs()
        proc = subprocess.run([
            "cmd", "/c", command
        ], capture_output=True, text=True, **kwargs)
    else:
        # On Linux/Unix, run command directly in shell
        proc = subprocess.run(
            command, 
            shell=True, 
            capture_output=True, 
            text=True
        )
    return proc.returncode


def handle_power(_cfc, message: dict):
    command = (message or {}).get("command")
    
    if platform.system().lower() == 'windows':
        if command == "shutdown":
            _run_cmd("shutdown /s /f /t 0")
        elif command == "restart":
            _run_cmd("shutdown /r /f /t 0")
        elif command == "sleep":
            _run_cmd("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
    else:
        # Linux commands
        if command == "shutdown":
            _run_cmd("shutdown -h now")
        elif command == "restart":
            _run_cmd("reboot")
        elif command == "sleep":
            _run_cmd("systemctl suspend")
    
    return
