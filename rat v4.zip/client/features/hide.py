import subprocess
import platform

def _get_subprocess_kwargs():
    """Get subprocess kwargs based on platform"""
    kwargs = {}
    if platform.system().lower() == 'windows':
        try:
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        except Exception:
            kwargs["creationflags"] = 0x08000000
    return kwargs