import pycurl
from io import BytesIO
from urllib.parse import urlparse, urlencode
import json as json_lib
from typing import Optional, Tuple, Union, Dict, Any, TypeVar
import tempfile
import os

T = TypeVar('T')

class CurlError(Exception):
    pass

class CurlManager:
    def __init__(self):
        try:
            self.curl: Optional[pycurl.Curl] = pycurl.Curl()
            self.current_proxy: Optional[str] = None
            self.cookies: Dict[str, str] = {}
            self.headers: Dict[str, str] = {}
            self._cookie_file = tempfile.NamedTemporaryFile(delete=False)
        except pycurl.error as e:
            raise CurlError(f"Failed to initialize curl: {str(e)}")

    def _validate_url(self, url: str) -> str:
        if not url:
            raise CurlError("URL cannot be empty")
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            raise CurlError(f"Invalid URL format: {url}")
        return url

    def _cleanup_resources(self) -> None:
        try:
            if self.curl:
                self.curl.close()
                self.curl = None
        except Exception:
            pass
        try:
            if hasattr(self, '_cookie_file'):
                cookie_path = self._cookie_file.name
                self._cookie_file.close()
                if os.path.exists(cookie_path):
                    try:
                        os.unlink(cookie_path)
                    except (OSError, PermissionError):
                        pass
        except Exception:
            pass

    def _reset_curl(self) -> None:
        try:
            if self.curl:
                self.curl.reset()
            else:
                self.curl = pycurl.Curl()
        except Exception as e:
            raise CurlError(f"Failed to reset curl: {str(e)}")

    def set_proxy(self, proxy_url: Optional[str]) -> None:
        if not proxy_url:
            self.current_proxy = None
            return
        try:
            proxy_url = self._validate_url(proxy_url)
            self.current_proxy = proxy_url
        except Exception as e:
            raise CurlError(f"Failed to set proxy: {str(e)}")

    def set_cookies(self, cookies: Dict[str, str]) -> None:
        self.cookies.update(cookies)
        cookie_list = [f"{k}={v};" for k, v in self.cookies.items()]
        with open(self._cookie_file.name, 'w') as f:
            f.write("\n".join(cookie_list))

    def get_cookies(self) -> Dict[str, str]:
        return self.cookies.copy()

    def set_headers(self, headers: Dict[str, str]) -> None:
        self.headers.update(headers)

    def get_headers(self) -> Dict[str, str]:
        return self.headers.copy()

    def _apply_proxy(self) -> None:
        if not self.current_proxy or not self.curl:
            return
        proxy_parts = urlparse(self.current_proxy)
        if '@' in proxy_parts.netloc:
            auth, proxy = proxy_parts.netloc.split('@')
            username, password = auth.split(':')
            self.curl.setopt(pycurl.PROXYUSERPWD, f"{username}:{password}")
            self.curl.setopt(pycurl.PROXY, proxy)
        else:
            self.curl.setopt(pycurl.PROXY, proxy_parts.netloc)
        self.curl.setopt(pycurl.PROXYTYPE, pycurl.PROXYTYPE_HTTP)

    def _setup_request(self, url: str, headers: Optional[Dict[str, str]] = None) -> BytesIO:
        try:
            url = self._validate_url(url)
            self._reset_curl()
            if not self.curl:
                raise CurlError("Curl not initialized")

            self._apply_proxy()

            buffer = BytesIO()
            self.curl.setopt(pycurl.WRITEDATA, buffer)
            self.curl.setopt(pycurl.URL, url)
            self.curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_1_1)
            self.curl.setopt(pycurl.FOLLOWLOCATION, True)
            self.curl.setopt(pycurl.CONNECTTIMEOUT, 10)
            self.curl.setopt(pycurl.TIMEOUT, 15)
            self.curl.setopt(pycurl.SSL_VERIFYPEER, 0)
            self.curl.setopt(pycurl.SSL_VERIFYHOST, 0)
            self.curl.setopt(pycurl.COOKIEFILE, self._cookie_file.name)
            self.curl.setopt(pycurl.COOKIEJAR, self._cookie_file.name)

            merged = self.headers.copy()
            if headers:
                merged.update(headers)

            if merged:
                header_list = [f"{k}: {v}" for k, v in merged.items()]
                self.curl.setopt(pycurl.HTTPHEADER, header_list)

            return buffer
        except Exception as e:
            raise CurlError(f"Failed to setup request: {str(e)}")

    def _parse_response(self, response_code: Optional[int], body: str, parse_json: bool = False) -> Tuple[Optional[int], Union[str, Dict[str, Any], None]]:
        if parse_json and body:
            try:
                return response_code, json_lib.loads(body)
            except json_lib.JSONDecodeError:
                return None, f"Failed to parse response as JSON: {body[:100]}..."
        return response_code, body

    def get(self, url: str, headers: Optional[Dict[str, str]] = None, parse_json: bool = False) -> Tuple[Optional[int], Union[str, Dict[str, Any], None]]:
        buffer = None
        try:
            buffer = self._setup_request(url, headers)
            self.curl.setopt(pycurl.HTTPGET, 1)
            self.curl.perform()
            response_code = self.curl.getinfo(pycurl.HTTP_CODE)
            body = buffer.getvalue().decode('utf-8', errors='ignore')
            return self._parse_response(response_code, body, parse_json)
        except pycurl.error as e:
            error_code, error_msg = e.args
            return None, f"Curl error {error_code}: {error_msg}"
        except Exception as e:
            return None, f"Request failed: {str(e)}"
        finally:
            if buffer:
                buffer.close()

    def post(self, url: str, data: Optional[Union[Dict[str, Any], str, bytes]] = None,
             json: Optional[Dict[str, Any]] = None,
             headers: Optional[Dict[str, str]] = None,
             parse_json: bool = False) -> Tuple[Optional[int], Union[str, Dict[str, Any], None]]:
        buffer = None
        try:
            merged_headers = self.headers.copy()
            if headers:
                merged_headers.update(headers)

            if json is not None:
                data = json_lib.dumps(json)
                merged_headers['Content-Type'] = 'application/json'

            buffer = self._setup_request(url, merged_headers)

            if isinstance(data, dict):
                data = urlencode(data)
            elif isinstance(data, str):
                data = data.encode('utf-8')

            if data:
                self.curl.setopt(pycurl.POSTFIELDS, data)

            self.curl.perform()
            response_code = self.curl.getinfo(pycurl.HTTP_CODE)
            body = buffer.getvalue().decode('utf-8', errors='ignore')
            return self._parse_response(response_code, body, parse_json)
        except pycurl.error as e:
            error_code, error_msg = e.args
            return None, f"Curl error {error_code}: {error_msg}"
        except Exception as e:
            return None, f"Request failed: {str(e)}"
        finally:
            if buffer:
                buffer.close()

    def post_file(self, url: str, file_path: str, field_name: str = 'file',
                additional_data: Optional[Dict[str, str]] = None,
                headers: Optional[Dict[str, str]] = None) -> Tuple[Optional[int], str]:
        buffer = None
        try:
            if not os.path.exists(file_path):
                raise CurlError(f"File not found: {file_path}")

            url = self._validate_url(url)
            self._reset_curl()
            if not self.curl:
                raise CurlError("Curl not initialized")

            self._apply_proxy()

            buffer = BytesIO()
            self.curl.setopt(pycurl.WRITEDATA, buffer)
            self.curl.setopt(pycurl.URL, url)
            self.curl.setopt(pycurl.HTTP_VERSION, pycurl.CURL_HTTP_VERSION_1_1)
            self.curl.setopt(pycurl.FOLLOWLOCATION, True)
            self.curl.setopt(pycurl.CONNECTTIMEOUT, 10)
            self.curl.setopt(pycurl.TIMEOUT, 15)
            self.curl.setopt(pycurl.SSL_VERIFYPEER, 0)
            self.curl.setopt(pycurl.SSL_VERIFYHOST, 0)
            self.curl.setopt(pycurl.COOKIEFILE, self._cookie_file.name)
            self.curl.setopt(pycurl.COOKIEJAR, self._cookie_file.name)

            merged = self.headers.copy()
            if headers:
                merged.update(headers)

            if merged:
                header_list = [f"{k}: {v}" for k, v in merged.items() if k.lower() != "content-type"]
                self.curl.setopt(pycurl.HTTPHEADER, header_list)

            form_data = []

            if additional_data:
                for key, value in additional_data.items():
                    form_data.append((key, value))

            form_data.append((field_name, (
                pycurl.FORM_FILE, file_path,
                pycurl.FORM_CONTENTTYPE, "application/octet-stream"
            )))

            self.curl.setopt(pycurl.HTTPPOST, form_data)

            self.curl.perform()
            response_code = self.curl.getinfo(pycurl.HTTP_CODE)
            body = buffer.getvalue().decode('utf-8', errors='ignore')

            return response_code, body
        except pycurl.error as e:
            error_code, error_msg = e.args
            return None, f"Curl error {error_code}: {error_msg}"
        except Exception as e:
            return None, f"File upload failed: {str(e)}"
        finally:
            if buffer:
                buffer.close()