import subprocess
import threading
import queue
import time
import platform
from features.hide import _get_subprocess_kwargs

class PersistentShell:
    def __init__(self):
        self.process = None
        self.stdout_queue = None
        self.stderr_queue = None
        self.stdout_thread = None
        self.stderr_thread = None
        self.close_requested = False
        self.initialized = False
    
    def start_shell(self):
        """Start the shell process (cmd on Windows, bash on Linux)"""
        if self.process and self.process.poll() is None:
            # Shell is already running
            return True
            
        try:
            # Choose shell based on platform
            if platform.system().lower() == 'windows':
                shell_cmd = ["cmd.exe"]
                kwargs = _get_subprocess_kwargs()
            else:
                shell_cmd = ["/bin/bash"]
                kwargs = {}
            
            # Start the shell process
            self.process = subprocess.Popen(
                shell_cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=0,
                universal_newlines=True,
                **kwargs
            )
            
            # Flag to indicate when to close
            self.close_requested = False
            
            def read_output(pipe, q):
                """Read output from pipe and put it in queue"""
                for line in iter(pipe.readline, ''):
                    if self.close_requested:
                        break
                    q.put(line)
                pipe.close()
            
            # Create queues for stdout and stderr
            self.stdout_queue = queue.Queue()
            self.stderr_queue = queue.Queue()
            
            # Start threads to read stdout and stderr
            self.stdout_thread = threading.Thread(target=read_output, args=(self.process.stdout, self.stdout_queue))
            self.stderr_thread = threading.Thread(target=read_output, args=(self.process.stderr, self.stderr_queue))
            self.stdout_thread.daemon = True
            self.stderr_thread.daemon = True
            self.stdout_thread.start()
            self.stderr_thread.start()
            
            # Give the shell time to initialize
            time.sleep(0.1)
            
            # Clear any initial output
            while not self.stdout_queue.empty():
                try:
                    self.stdout_queue.get_nowait()
                except queue.Empty:
                    break
            
            self.initialized = True
            return True
            
        except Exception as e:
            print(f"Failed to start shell: {str(e)}")
            return False
    
    def execute_command(self, command):
        """Execute a command in the persistent shell"""
        if not self.initialized or not self.process or self.process.poll() is not None:
            if not self.start_shell():
                return "Error: Failed to start shell"
        
        if command.upper() == "CLOSE":
            return self.close_shell()
        
        try:
            # Send command to shell
            self.process.stdin.write(command + "\n")
            self.process.stdin.flush()
            
            # Small delay to allow command to execute
            time.sleep(0.1)
            
            # Collect output as it becomes available
            output_lines = []
            output_received = False
            start_time = time.time()
            while time.time() - start_time < 2:  # Wait up to 2 seconds for output
                try:
                    # Try to get output from stdout queue
                    line = self.stdout_queue.get_nowait()
                    if line.strip() and not line.startswith("$"):
                        output_lines.append(line)
                        output_received = True
                except queue.Empty:
                    try:
                        # Try to get output from stderr queue
                        line = self.stderr_queue.get_nowait()
                        if line.strip() and not line.startswith("$"):
                            output_lines.append(line)
                            output_received = True
                    except queue.Empty:
                        # No more output available right now
                        if output_received:
                            break
                        time.sleep(0.01)
            
            # If no output was received, return empty string
            return "".join(output_lines)
            
        except Exception as e:
            return f"Error executing command: {str(e)}"
    
    def close_shell(self):
        """Close the shell process"""
        if self.process and self.process.poll() is None:
            try:
                self.close_requested = True
                self.process.stdin.write("exit\n")
                self.process.stdin.flush()
                self.process.wait(timeout=5)  # Wait up to 5 seconds for process to exit
            except:
                # Force kill if it doesn't exit gracefully
                try:
                    self.process.kill()
                except:
                    pass
        self.initialized = False
        return "Shell closed"