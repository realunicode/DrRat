import threading


class ServerManager:
    """Thread-safe registry for connected Socket.IO session IDs (sids)."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._sids = set()
        self.instructions = {}

    def add_sid(self, sid: str) -> None:
        if not sid:
            return
        with self._lock:
            self._sids.add(sid)

    def remove_sid(self, sid: str) -> None:
        if not sid:
            return
        with self._lock:
            if sid in self._sids:
                self._sids.remove(sid)

    def get_all_sids(self):
        with self._lock:
            return list(self._sids)

    def add_instruction(self, pc_id, data):
        """Add instruction for a client"""
        self.instructions[pc_id] = data
        
    def get_receive_data(self, pc_id):
        """Get and remove instructions for a client"""
        return self.instructions.pop(pc_id, None)

# Export a singleton instance for easy importing
server_manager = ServerManager()


