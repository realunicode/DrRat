import os
import json
import secrets

settings_file = os.path.join(os.path.expanduser('~'), '.cfc', 'settings.json')

os.makedirs(os.path.dirname(settings_file), exist_ok=True)

if not os.path.exists(settings_file):
    default_api_key = secrets.token_hex(32)
    
    default_settings = {
        'port': 5000,
        'api_key': default_api_key,
        'license_key': '',
    }
    
    with open(settings_file, 'w') as f:
        json.dump(default_settings, f)

try:
    with open(settings_file, 'r') as f:
        settings_data = json.load(f)
        API_KEY = settings_data.get('api_key')
        FLASK_PORT = int(settings_data.get('port'))
        LICENSE_KEY = settings_data.get('license_key')
except:
    raise Exception('Error loading settings file')