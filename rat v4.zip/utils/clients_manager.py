import time
import os
import json

class Clients:
    """Class to manage active clients"""
    def __init__(self):
        self.active_clients = {}
        self.clients_last_activity = {}
        self.instructions = {}
        self.timeout = 5
            
    def add_client(self, pc_id, client_data):
        """Add a new client"""
        self.active_clients[pc_id] = client_data
        self.clients_last_activity[pc_id] = time.time()  # Update last activity time

    def remove_client(self, pc_id):
        """Remove a client"""
        self.active_clients.pop(pc_id, None)
        self.clients_last_activity.pop(pc_id, None)  # Remove activity tracking
        self.instructions.pop(pc_id, None)  # Clean up instructions

    def get_active_clients(self):
        """Get list of active clients"""
        # Check for timed out clients and remove them
        current_time = time.time()
        timed_out_clients = []
        
        for pc_id, last_activity in self.clients_last_activity.items():
            if current_time - last_activity > self.timeout:
                timed_out_clients.append(pc_id)
        
        # Remove timed out clients
        for pc_id in timed_out_clients:
            self.remove_client(pc_id)
        
        return self.active_clients

    def update_client_activity(self, pc_id):
        """Update the last activity time for a client"""
        if pc_id in self.active_clients:
            self.clients_last_activity[pc_id] = time.time()

    def add_instruction(self, pc_id, data):
        """Add instruction for a client"""
        self.instructions[pc_id] = data
        
    def get_instructions(self, pc_id):
        """Get and remove instructions for a client"""
        self.update_client_activity(pc_id)
        return self.instructions.pop(pc_id, None)

    def clear_instructions(self, pc_id):
        self.instructions.pop(pc_id, None)

clients_manager = Clients()