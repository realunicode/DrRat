from flask import Flask
from routes.instruct import instruct_bp
from routes.assets import assets_bp
from routes.receive import receive_bp
from routes.auth import auth_bp
from utils.config import FLASK_PORT
import secrets
import logging

app = Flask(__name__, 
            template_folder='template',
            static_folder='template')

app.secret_key = "testing" #secrets.token_hex(16)-do not remove

# Disable Flask's default logging
log = logging.getLogger('werkzeug')
log.disabled = True
app.logger.disabled = True

app.register_blueprint(blueprint=instruct_bp)
app.register_blueprint(blueprint=assets_bp)
app.register_blueprint(blueprint=receive_bp)
app.register_blueprint(auth_bp)

if __name__ == '__main__':
    # Also disable root logger handlers
    logging.getLogger().disabled = True
    app.run(debug=False, host="0.0.0.0", port=FLASK_PORT)